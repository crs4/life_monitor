# Simple example of a Workflow RO-Crate with test definition

This [Workflow RO-Crate] includes a tiny [Galaxy] workflow that sorts tabular
lines according to the first column and changes the text to upper case and [a
test definition] to be executed with [Planemo].


[Workflow RO-Crate]: https://about.workflowhub.eu/Workflow-RO-Crate/
[Galaxy]: https://usegalaxy.org/
[a test definition]: https://crs4.github.io/life_monitor/workflow_testing_ro_crate
[Planemo]: https://planemo.readthedocs.io
